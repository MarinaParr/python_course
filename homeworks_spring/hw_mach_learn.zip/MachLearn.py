import numpy as np
from scipy.ndimage import imread
import os
def get_images(dir_name):
    images = []
    for file_name in os.listdir(dir_name):
        x = imread(dir_name + "/" + file_name, flatten=True)
        x.shape = (10000, )
        images.append(x)
    images = np.array(images)
    return images
planes = get_images("airplanes")
bikes = get_images("Motorbikes")
np.random.shuffle(planes)
np.random.shuffle(bikes)
train_planes = planes[:200, ]
validate_planes = planes[200: ]
train_bikes = bikes[:200, ]
validate_bikes = bikes[200: ]
train = np.concatenate((train_planes, train_bikes))
validate = np.concatenate((validate_planes, validate_bikes))
train_y = np.array((np.ones(200), np.zeros(200)))
train_y.shape = (400, )
def mach_learn(algorythm, n_est):
    from sklearn.ensemble import RandomForestClassifier
    if algorythm == "RandomForestClassifier":
        prediction = RandomForestClassifier(n_estimators=n_est)
    from sklearn.ensemble import ExtraTreesClassifier
    if algorythm == "ExtraTreesClassifier":
        prediction = ExtraTreesClassifier(n_estimators=n_est)
    from sklearn.ensemble import AdaBoostClassifier
    if algorythm == "AdaBoostClassifier":
        prediction = AdaBoostClassifier(n_estimators=n_est)
    from sklearn.ensemble import GradientBoostingClassifier
    if algorythm == "GradientBoostingClassifier":
        prediction = GradientBoostingClassifier(n_estimators=n_est)
    prediction = prediction.fit(train, train_y)
    validate_y = np.concatenate((np.ones(50), np.zeros(50)))
    predicted_y = prediction.predict(validate)
    from sklearn.metrics.classification import accuracy_score
    return(accuracy_score(validate_y, predicted_y))
print('\t'+'n_estimators')
s = ["Algorythm", 10, 20, 40, 80, 100, 150, 200, 300, 400, 500, 1000]
print('\t'.join(map(str, s)))
for algorythm in ["RandomForestClassifier", "ExtraTreesClassifier", "AdaBoostClassifier", "GradientBoostingClassifier"]:
    l = list()
    l.append(algorythm)
    for n_est in [10, 20, 40, 80, 100, 150, 200, 300, 400, 500, 1000]:
        i = 1
        accuracy = 0
        while i != 11:
            accuracy += (mach_learn(algorythm, n_est)/10)
            i+=1
        l.append(accuracy)
    print('\t'.join(map(str, l)))
